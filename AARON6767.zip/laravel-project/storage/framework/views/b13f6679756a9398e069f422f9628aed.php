<?php $__env->startSection('title', 'Class Schedule'); ?>
<?php $__env->startSection('page-title', 'Class Schedule'); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item active">Schedules</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <div>
        <h1><i class="bi bi-calendar3 me-2" style="color:var(--primary);"></i>Class Schedule</h1>
        <p class="text-muted mb-0" style="font-size:.85rem;">Your personal class schedule for the semester.</p>
    </div>
    <a href="<?php echo e(route('schedules.create')); ?>" class="btn btn-primary">
        <i class="bi bi-plus-circle-fill me-2"></i>Add Schedule
    </a>
</div>

<!-- Filters -->
<div class="card mb-4">
    <div class="card-body py-3">
        <form method="GET" action="<?php echo e(route('schedules.index')); ?>" class="d-flex flex-wrap gap-2 align-items-center">
            <div class="input-group" style="max-width:320px;">
                <span class="input-group-text bg-white"><i class="bi bi-search text-muted"></i></span>
                <input type="text" name="search" class="form-control" placeholder="Search subject, code, instructor..." value="<?php echo e($search); ?>">
            </div>
            <select name="day" class="form-select" style="width:auto;">
                <option value="">All Days</option>
                <?php $__currentLoopData = $days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($d); ?>" <?php echo e($filterDay === $d ? 'selected' : ''); ?>><?php echo e($d); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <button class="btn btn-primary" type="submit">Filter</button>
            <?php if($search || $filterDay): ?>
                <a href="<?php echo e(route('schedules.index')); ?>" class="btn btn-outline-secondary">Clear</a>
            <?php endif; ?>
        </form>
    </div>
</div>

<!-- Table -->
<div class="card">
    <div class="card-header d-flex align-items-center justify-content-between">
        <span>All Schedules <span class="badge" style="background:var(--accent-soft);color:var(--primary);font-weight:600;"><?php echo e($schedules->total()); ?></span></span>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Subject</th>
                        <th>Instructor</th>
                        <th>Day</th>
                        <th>Time</th>
                        <th>Room</th>
                        <th>Semester</th>
                        <th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="text-muted" style="font-size:.8rem;"><?php echo e($schedules->firstItem() + $loop->index); ?></td>
                        <td>
                            <div class="d-flex align-items-center gap-2">
                                <span style="display:inline-block;width:12px;height:12px;border-radius:3px;background:<?php echo e($s->color); ?>;flex-shrink:0;"></span>
                                <div>
                                    <div class="fw-bold" style="font-size:.875rem;"><?php echo e($s->subject_name); ?></div>
                                    <div class="text-muted" style="font-size:.75rem;"><?php echo e($s->subject_code); ?></div>
                                </div>
                            </div>
                        </td>
                        <td style="font-size:.85rem;"><?php echo e($s->instructor); ?></td>
                        <td>
                            <span class="badge-day" style="background:<?php echo e($s->color); ?>22;color:<?php echo e($s->color); ?>;border:1px solid <?php echo e($s->color); ?>44;">
                                <?php echo e($s->day); ?>

                            </span>
                        </td>
                        <td style="font-size:.8rem;white-space:nowrap;">
                            <?php echo e(\Carbon\Carbon::parse($s->start_time)->format('h:i A')); ?><br>
                            <span class="text-muted"><?php echo e(\Carbon\Carbon::parse($s->end_time)->format('h:i A')); ?></span>
                        </td>
                        <td style="font-size:.85rem;"><?php echo e($s->room); ?></td>
                        <td style="font-size:.8rem;color:#6b7280;"><?php echo e($s->semester); ?><br><?php echo e($s->school_year); ?></td>
                        <td class="text-end">
                            <a href="<?php echo e(route('schedules.edit', $s)); ?>" class="btn btn-sm btn-outline-primary me-1">
                                <i class="bi bi-pencil-fill"></i>
                            </a>
                            <form method="POST" action="<?php echo e(route('schedules.destroy', $s)); ?>" class="d-inline"
                                  onsubmit="return confirmDelete('<?php echo e($s->subject_name); ?>')">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-outline-danger">
                                    <i class="bi bi-trash-fill"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="8" class="text-center py-5 text-muted">
                            <i class="bi bi-calendar-x" style="font-size:2.5rem;opacity:.25;display:block;margin-bottom:8px;"></i>
                            No schedules found.
                            <br>
                            <a href="<?php echo e(route('schedules.create')); ?>" class="btn btn-sm btn-primary mt-3">
                                <i class="bi bi-plus-circle me-1"></i>Add First Schedule
                            </a>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php if($schedules->hasPages()): ?>
    <div class="card-footer bg-white d-flex justify-content-between align-items-center">
        <small class="text-muted">Showing <?php echo e($schedules->firstItem()); ?>–<?php echo e($schedules->lastItem()); ?> of <?php echo e($schedules->total()); ?></small>
        <?php echo e($schedules->links()); ?>

    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
function confirmDelete(name) {
    return confirm(`Delete schedule for "${name}"?`);
}
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-project\resources\views/schedules/index.blade.php ENDPATH**/ ?>