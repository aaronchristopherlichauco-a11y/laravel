<?php $__env->startSection('title', 'Users Management'); ?>
<?php $__env->startSection('page-title', 'Users Management'); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item active">Users</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <div>
        <h1><i class="bi bi-people-fill me-2" style="color:var(--primary);"></i>Users Management</h1>
        <p class="text-muted mb-0" style="font-size:.85rem;">Manage all registered users in the system.</p>
    </div>
    <a href="<?php echo e(route('users.create')); ?>" class="btn btn-primary">
        <i class="bi bi-person-plus-fill me-2"></i>Add User
    </a>
</div>

<!-- Search -->
<div class="card mb-4">
    <div class="card-body py-3">
        <form method="GET" action="<?php echo e(route('users.index')); ?>" class="d-flex gap-2">
            <div class="input-group">
                <span class="input-group-text bg-white"><i class="bi bi-search text-muted"></i></span>
                <input type="text" name="search" class="form-control" placeholder="Search by name or email..." value="<?php echo e($search); ?>">
            </div>
            <button class="btn btn-primary px-4" type="submit">Search</button>
            <?php if($search): ?>
                <a href="<?php echo e(route('users.index')); ?>" class="btn btn-outline-secondary px-4">Clear</a>
            <?php endif; ?>
        </form>
    </div>
</div>

<!-- Table -->
<div class="card">
    <div class="card-header d-flex align-items-center justify-content-between">
        <span>All Users <span class="badge" style="background:var(--accent-soft);color:var(--primary);font-weight:600;"><?php echo e($users->total()); ?></span></span>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Created Date</th>
                        <th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="text-muted" style="font-size:.8rem;"><?php echo e($users->firstItem() + $loop->index); ?></td>
                        <td>
                            <div class="d-flex align-items-center gap-2">
                                <div class="sidebar-user-avatar" style="width:34px;height:34px;font-size:.75rem;background:var(--primary);flex-shrink:0;">
                                    <?php if($user->avatar): ?>
                                        <img src="<?php echo e(Storage::url($user->avatar)); ?>" alt="">
                                    <?php else: ?>
                                        <?php echo e(strtoupper(substr($user->name, 0, 1))); ?>

                                    <?php endif; ?>
                                </div>
                                <div>
                                    <div class="fw-600" style="font-weight:600;"><?php echo e($user->name); ?></div>
                                    <?php if($user->id === Auth::id()): ?>
                                        <span class="badge" style="background:var(--accent-soft);color:var(--primary);font-size:.68rem;">You</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </td>
                        <td><a href="mailto:<?php echo e($user->email); ?>" class="text-decoration-none" style="color:var(--primary);"><?php echo e($user->email); ?></a></td>
                        <td><span style="font-size:.82rem;color:#6b7280;"><?php echo e($user->created_at->format('M d, Y')); ?></span></td>
                        <td class="text-end">
                            <a href="<?php echo e(route('users.edit', $user)); ?>" class="btn btn-sm btn-outline-primary me-1">
                                <i class="bi bi-pencil-fill"></i>
                            </a>
                            <?php if($user->id !== Auth::id()): ?>
                            <form method="POST" action="<?php echo e(route('users.destroy', $user)); ?>" class="d-inline" onsubmit="return confirmDelete('<?php echo e($user->name); ?>')">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-outline-danger">
                                    <i class="bi bi-trash-fill"></i>
                                </button>
                            </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="text-center py-5 text-muted">
                            <i class="bi bi-people" style="font-size:2.5rem;opacity:.25;display:block;margin-bottom:8px;"></i>
                            No users found.
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php if($users->hasPages()): ?>
    <div class="card-footer bg-white d-flex justify-content-between align-items-center" style="border-top:1px solid var(--gray-200);">
        <small class="text-muted">Showing <?php echo e($users->firstItem()); ?>–<?php echo e($users->lastItem()); ?> of <?php echo e($users->total()); ?></small>
        <?php echo e($users->links()); ?>

    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
function confirmDelete(name) {
    return confirm(`Are you sure you want to delete user "${name}"? This action cannot be undone.`);
}
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-project\resources\views/users/index.blade.php ENDPATH**/ ?>